# Diagnostic Stress Triage

## Fixes applied
- Construction changes:
  - Split suite into Layer A (golden prop-level W_hat) and Layer B (token pipeline TopK/collapse/PermRow).
  - Built DAG and cycle graphs with matched out-degree (2 for nodes 0–5, 0 for sinks 6–7) and fixed weights (w_hi=0.9, w_lo=0.1).
  - Cycle edges use w_hi; low edges go to sinks to avoid extra cycles.
  - Premises set to propositions [2,3] for PR/Cyc tests to avoid nilpotent collapse at s=5.
  - Chain localization uses premise blocks [0,1], candidate blocks [6,7], with k_tok=2*block_size per T.
- Threshold/criterion change:
  - For k=2 only, skip sym-control comparison in DeltaCyc sign test (directed 2-cycle is already bidirectional).

## Golden-layer evidence (key stats)
T32:
- DAG DeltaCyc: {2: 0.0, 3: 0.0, 4: 0.0}
- C2 Cyc: {2: 0.81, 3: 0.0, 4: 0.32805}, DeltaCyc: {2: 0.5704, 3: 0.0, 4: 0.2474}
- C3 Cyc: {2: 0.0, 3: 0.729, 4: 0.0}, DeltaCyc: {2: 0.0, 3: 0.57024, 4: 0.0}
- C4 Cyc: {2: 0.0, 3: 0.0, 4: 0.6561}, DeltaCyc: {2: 0.0, 3: 0.0, 4: 0.615496}
- PR DAG: 0.0; PR cycles: [4.0, 4.0, 3.0]

T64:
- DAG DeltaCyc: {2: 0.0, 3: 0.0, 4: 0.0}
- C2 Cyc: {2: 0.81, 3: 0.0, 4: 0.32805}, DeltaCyc: {2: 0.6184, 3: 0.0, 4: 0.26996}
- C3 Cyc: {2: 0.0, 3: 0.729, 4: 0.0}, DeltaCyc: {2: 0.0, 3: 0.59408, 4: 0.0}
- C4 Cyc: {2: 0.0, 3: 0.0, 4: 0.6561}, DeltaCyc: {2: 0.0, 3: 0.0, 4: 0.60756}
- PR DAG: 0.0; PR cycles: [4.0, 4.0, 3.0]
