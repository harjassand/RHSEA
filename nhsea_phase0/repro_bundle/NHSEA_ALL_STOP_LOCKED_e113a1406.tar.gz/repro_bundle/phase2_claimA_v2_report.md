# Phase 2 Report

## Claim A (SelLocGap)
- seed 0: SelLocGap mean=0.004465 CI=[0.003639,0.005331] rho_median=1.002972 rho_flag=False
- seed 1: SelLocGap mean=0.008414 CI=[0.008043,0.008784] rho_median=1.013125 rho_flag=False
- seed 2: SelLocGap mean=0.001402 CI=[0.000974,0.001831] rho_median=0.998653 rho_flag=False
- pooled SelLocGap mean=0.004760 CI=[0.004412,0.005104]
- status: see CI and rho_flag per seed

## Claim B (Cycle diagnostics, mechanism)
