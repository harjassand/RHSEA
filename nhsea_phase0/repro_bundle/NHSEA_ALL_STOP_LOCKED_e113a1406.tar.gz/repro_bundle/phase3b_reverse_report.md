# Phase 3b Reverse Reciprocity Report

pooled_forward_mechanism=0.5057 CI=[0.5000,0.5113]
pooled_forward_no_injection=0.5057 CI=[0.5000,0.5113]
pooled_delta(mech - baseline)=0.0000 CI=[0.0000,0.0000]
reverse_gap_present=False

Per-seed delta (mech - baseline):
- seed 0: delta=0.0000 CI=[0.0000,0.0000]
- seed 1: delta=0.0000 CI=[0.0000,0.0000]
- seed 2: delta=0.0000 CI=[0.0000,0.0000]

SelLocGap (mech - sym v2) per seed:
- seed 0: mean=0.0001 CI=[-0.0001,0.0003]
- seed 1: mean=-0.0002 CI=[-0.0004,0.0001]
- seed 2: mean=0.0001 CI=[-0.0004,0.0005]
